<?php

define('__GOOSE__', true);
define('__PWD__', dirname(__FILE__));

// 경로지정 필요합니다.
require_once('../goose/core/lib.php');
require_once('layout.html');
