<?php

define('__GOOSE__', true);
define('__PWD__', dirname(__FILE__));

error_reporting(E_ALL);
ini_set("display_errors", 1);

// 경로지정 필요합니다.
require_once('../goose/core/lib.php');
require_once('layout.html');
