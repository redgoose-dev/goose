<?php
if (!defined('__GOOSE__')) exit();

class Helloworld {

	public $goose;

	public function index()
	{
		echo "hello world";
	}
}

